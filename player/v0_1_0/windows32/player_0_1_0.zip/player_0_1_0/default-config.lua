
-- Set a path for searching your image file ... etc.
search_path = Toy_ResourcePathForDemo

-- Set the main script of your project.
script = "main.lua"

-- Set a path for searching main script of project.
--main_path = "examples/HelloWorld"
main_path = "examples/Window"              -- Show a empty window.
