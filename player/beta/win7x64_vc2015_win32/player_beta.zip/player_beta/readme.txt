Type this to get more information
$ player.exe --help


"default-config.lua" is a config file for "player.exe".
"player-gui.json" is a record file for "player-gui.exe".
