
return
{
	export = function(filename,buffer)
		require("toy.file")._export_png_file(filename,buffer)
	end
}
