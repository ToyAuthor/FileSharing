
return
{
	load_image = function(stream,buffer)
		stream:_load_image(buffer)
	end,
}
