
-- Set a path for searching your image file, font file, etc.
search_path = "."

-- Set the main script of your project.
script = "main.lua"

-- Set a path for searching main script of project.
main_path = "examples/HelloWorld"
