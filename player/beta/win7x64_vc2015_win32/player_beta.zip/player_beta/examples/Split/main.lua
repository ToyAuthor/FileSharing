
local  msg = require "toy.logger"
local  bug = require "toy.debug"

local function main()
	msg.print("哈哈")

	local splitter = require("toy.split").create_splitter()

	splitter:load_ex("D:/code/ToyBox/resource/lua/examples/CheckGlobalName.txt","right")

	splitter:push_config({
	--	ignore = { " " },
		break_char = {".","/"},
	})

	local str = splitter:next()

	while str do
		msg.print("str:" .. str)
		str = splitter:next()
	end
end

if bug.catch(main) then
	msg.print("error happened:")
end
