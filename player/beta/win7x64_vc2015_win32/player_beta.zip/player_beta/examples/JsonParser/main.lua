
local  msg = require "toy.logger"
local  bug = require "toy.debug"
local  tab = require "toy.table"
local  jsn = require "toy.file.io.json"
local  txt = require "toy.txtio"
local  sys = require "toy.root"

local function load_json_file(filename)
	local   reader = txt.new_reader(filename)
	local   buffer = ""
	local   str

	repeat
		str = reader:next_line()   -- Return nil if there is no next line.
		if str then
			buffer = buffer .. str
		end
	until ( str==nil )

	return buffer
end

local function main()
	local   buffer = load_json_file(sys.get_resource_path() .. "/text.json")

	-- jsn.import convert raw string to a table.
	-- tab.print just print the content of table.
	tab.print( jsn.import(buffer), msg.print )
end

-- Just a try-catch block
if bug.catch(main) then
	bug.oops()
end
