
local  msg = require "toy.logger"
local  rex = require "toy.regex"
local  bug = require "toy.debug"

local function get_filename_extension(str)

	local times = 0
	local ans = "nothing"

	local function view_result(var)
		times = times+1

		if times==1 then    -- take the first one.
			ans = var
		end
	end

	if not rex.search([[(?<=[^/][\.])\w*$]],str,view_result) then
		ans = nil
	end

	return ans
end

local function main()
	msg.print(get_filename_extension("sample.bmp"))
end

if bug.catch(main) then
	bug.oops()
end
