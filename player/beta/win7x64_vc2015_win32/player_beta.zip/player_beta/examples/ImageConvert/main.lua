
local sys  = require "toy.root"
local bug  = require "toy.debug"
local file = require "toy.file"

local function main()
	local load_image = require("toy.file.loader.image").load_image

	local stream = file.create_stream("default")

	local function load_image_file(folder,filename)

		local buffer = file.create_image_buffer()

		stream:open_dir(folder)
		stream:open(filename)
		load_image(stream,buffer)

		return buffer
	end

	buffer = load_image_file(sys.get_resource_path() .. "/package.7z","大阪城.bmp")

	require("toy.file.export.png").export(sys.get_resource_path() .. "大阪城.png",buffer)
--	buffer = load_image_file("C:/Users/Jack/Desktop","0ddffww03.webp")
--	require("toy.file.export.png").export("C:/Users/Jack/Desktop/0ddffww03.png",buffer)
end

if bug.catch(main) then
	bug.oops()
end
